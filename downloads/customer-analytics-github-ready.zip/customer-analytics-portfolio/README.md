# Customer analytics and return-risk prototype

A transparent, reproducible order-line and customer analysis, with temporal model validation and an executive brief. The project demonstrates careful joins, data-quality checks, descriptive statistics, inferential uncertainty, and a batch-scoring prototype.

## Setup and run
1. Extract the ZIP and open PowerShell in the extracted project directory.
2. Create and activate an isolated Python 3.11 environment:

   ```powershell
   py -3.11 -m venv .venv
   .\.venv\Scripts\Activate.ps1
   python -m pip install -r requirements.txt
   ```

3. Place `customers.csv`, `orders.csv`, and `returns.csv` in `data/raw/`. The local project folder already includes your copies; the shareable ZIP excludes them.
4. Run `jupyter notebook`, open `notebooks/customer_analytics.ipynb`, and select the Python kernel from the activated environment.
5. Select **Kernel → Restart Kernel and Run All Cells**. Outputs appear in `reports/` and `models/`.

Source CSVs and trained model files are excluded from Git. Aggregate reports and executed notebook outputs can still reveal business-sensitive data: inspect them and confirm publication rights before sharing.

The analysis has already been run on the supplied files. The executed notebook retains its tables and figures, and `reports/customer_analytics.html` provides a browser-readable copy. `reports/executive_report.html` is a concise management brief. The dated observations cover 2014–2017; they should not be presented as current results.

## Batch-scoring prototype
After training, provide a CSV with one row per order and columns `sales,units,line_count,category_count,discount_weighted,month,segment,ship_mode`. Optional `order_reference` is echoed in the output. The fields must be known at order placement and calculated exactly as in the notebook. Run:

```bash
python src/score_batch.py --input path/to/orders_to_score.csv --output path/to/scores.csv
```

`discount_weighted` is sum(line discount × line units) / sum(line units), in [0,1]. Categories unseen during training are accepted and encoded as all zero. Output scores are probabilities from the prototype; they are not decisions or validated deployment recommendations. Only load trusted joblib files.

## Analysis design
The source order table is at line level; order-level outcomes are built separately. Customer location records cannot be linked reliably to order lines, so only segment and country are joined after consistency checks. Missing return-file matches are treated as not observed returned, assuming a complete extract. Return dates and item-level refund amounts are not available. The last year is a later holdout; the prior year selects the candidate using average precision. Labels lack event dates, so maturity and temporal availability are unverified. A production release needs updated data, mature outcomes, calibration, monitoring, security and stakeholder review.
